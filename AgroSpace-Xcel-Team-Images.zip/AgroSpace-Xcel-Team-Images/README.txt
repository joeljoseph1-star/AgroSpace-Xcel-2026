AGROSPACE XCEL - TEAM PHOTOS

Put the entire 'images' folder into your website folder.

Files:
joel.jpg = Joel Joseph Lester Sellep (Team Leader)
rafael.jpg = Rafael Dean Richard
lim-wei-jiun.jpg = Lim Wei Jiun
rajiv.jpg = Rajiv Akhiilendra A/L Supramaniam
ahmad.jpg = Ahmad Quisyri Azim Bin Ahmad Zafir

# AgroSpace Xcel — FieldShift

GitHub Pages-ready website package.

## Important
Keep the `images` folder exactly where it is. The team photos are referenced as:
- images/joel.jpg
- images/rafael.jpg
- images/lim-wei-jiun.jpg
- images/rajiv.jpg
- images/ahmad-quisyri.jpg

Do not rename the files unless you also update `index.html`.
